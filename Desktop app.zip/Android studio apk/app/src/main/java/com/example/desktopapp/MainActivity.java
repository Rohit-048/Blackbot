package com.example.desktopapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView responseTextView;
    private SpeechRecognizer speechRecognizer;
    private IntentRecognizer intentRecognizer;
    private TextToSpeech textToSpeech;

    // List of jokes
    private List<String> jokes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        responseTextView = findViewById(R.id.responseTextView);
        Button listenButton = findViewById(R.id.listenButton);

        // Initialize SpeechRecognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListenerImpl());

        // Initialize IntentRecognizer
        intentRecognizer = new IntentRecognizer(this, this::onSpeechResult);

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(Locale.US);

                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TextToSpeech", "Language not supported");
                } else {
                    // Greet the user when the app is opened
                    speak("Hi Rohit, I am NexusAI. How can I help you?");
                }
            } else {
                Log.e("TextToSpeech", "Initialization failed");
            }
        });

        // Initialize list of jokes
        initializeJokes();

        // Set onClickListener for the Listen button
        listenButton.setOnClickListener(v -> startListening());

        // Adjust padding based on system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Helper method to start voice recognition
    private void startListening() {
        intentRecognizer.startForResult.launch(intentRecognizer.intent);
    }

    // Callback for speech recognition results
    private void onSpeechResult(ArrayList<String> results) {
        if (results != null && !results.isEmpty()) {
            String query = results.get(0).toLowerCase();

            if (query.contains("open camera")) {
                openCamera();
            } else if (query.contains("open whatsapp")) {
                openWhatsApp();
            } else if (query.contains("tell me a joke")) {
                tellJoke();
            } else {
                responseTextView.setText("Unrecognized command");
                speak("Unrecognized command");
            }
        }
    }

    private void openCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            responseTextView.setText("Camera app not available");
            speak("Camera app not available");
            Log.d("Assistant", "Camera app not available");
        }
    }

    private void openWhatsApp() {
        String phoneNumber = "6202985338"; // Replace with the phone number you want to chat with
        String url = "https://wa.me/" + phoneNumber;

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            responseTextView.setText("WhatsApp not supported or not installed");
            speak("WhatsApp not supported or not installed");
            Log.d("Assistant", "WhatsApp not supported or not installed");
        }
    }

    private void tellJoke() {
        // Randomly select a joke from the list
        Random random = new Random();
        int index = random.nextInt(jokes.size());
        String joke = jokes.get(index);

        // Display the joke with an emoji
        String response = "Okay Rohit, Here's a joke for you: \n" + joke;
        responseTextView.setText(response);
        speak(response);
    }

    // Text-to-Speech function
    private void speak(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }

        // Shutdown TextToSpeech
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }

    private class RecognitionListenerImpl implements RecognitionListener {
        @Override
        public void onReadyForSpeech(Bundle params) {
            // Implementation for onReadyForSpeech
        }

        @Override
        public void onBeginningOfSpeech() {
            // Implementation for onBeginningOfSpeech
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            // Implementation for onRmsChanged
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
            // Implementation for onBufferReceived
        }

        @Override
        public void onEndOfSpeech() {
            // Implementation for onEndOfSpeech
        }

        @Override
        public void onError(int error) {
            // Implementation for onError
        }

        @Override
        public void onResults(Bundle results) {
            // Implementation for onResults
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            // Implementation for onPartialResults
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
            // Implementation for onEvent
        }
    }

    // Initialize the list of jokes
    private void initializeJokes() {
        jokes = new ArrayList<>();
        jokes.add("Why did the scarecrow win an award? Because he was outstanding in his field!");
        jokes.add("What do you get when you cross a snowman and a vampire? Frostbite!");
        jokes.add("Why don't scientists trust atoms? Because they make up everything!");
        jokes.add("How does a penguin build its house? Igloos it together!");
        jokes.add("What's brown and sticky? A stick!");
        jokes.add("Why don't skeletons fight each other? They don't have the guts!");
        jokes.add("What did one wall say to the other wall? 'I'll meet you at the corner.'");
        jokes.add("Why did the bicycle fall over? It was two-tired!");
        jokes.add("How do you organize a space party? You planet!");
        jokes.add("Why did the tomato turn red? Because it saw the salad dressing!");
        jokes.add("What did the janitor say when he jumped out of the closet? Supplies!");
        jokes.add("Why don't oysters donate to charity? Because they are shellfish!");
        jokes.add("What's orange and sounds like a parrot? A carrot!");
        jokes.add("Why did the math book look sad? Because it had too many problems!");
        jokes.add("What did one plate say to another plate? 'Tonight, dinner's on me!'");
        jokes.add("Why don't scientists trust atoms? Because they make up everything!");
        jokes.add("What did the grape do when it got stepped on? Nothing, but it let out a little wine!");
        jokes.add("How do you make a tissue dance? You put a little boogie in it!");
        jokes.add("Why did the computer go to therapy? Because it had too many bytes of emotional baggage!");
        jokes.add("What do you call a fish wearing a crown? A kingfish!");
    }
}
